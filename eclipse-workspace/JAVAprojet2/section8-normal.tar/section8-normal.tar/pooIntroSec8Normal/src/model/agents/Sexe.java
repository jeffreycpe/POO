package model.agents;

public enum Sexe {
	Male,Femelle,Assexue
}

package model.agents.animaux;

import java.awt.Point;

import model.agents.Sexe;

public class FrelonAsiatique extends Frelon{

	public FrelonAsiatique(Sexe s, Point p) {
		/*
		 * TODO
		 */
	}

	

}
